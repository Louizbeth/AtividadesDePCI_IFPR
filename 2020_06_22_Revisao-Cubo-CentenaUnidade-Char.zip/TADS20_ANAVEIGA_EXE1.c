#include <stdio.h>
#include <stdlib.h>

int main() {
    system("clear");
    int num,qua,cub;
    printf("Digite um número:");
    scanf("%i", &num);
    qua = num*num;
    cub = num*num*num;
    printf("Quadrado: %i\n", qua); 
    printf("Cubo: %i\n", cub); 
    
//Ana Carolina Veiga da Silva TADS20
}