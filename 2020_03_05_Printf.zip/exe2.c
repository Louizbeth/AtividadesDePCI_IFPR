#include <stdio.h>
#include <stdlib.h>

int main() {
    system("clear");
    printf("\t\t >Cachorro: Gaia\n>Raça: Bulldog Inglês\n\t>Idade: 3 anos e meio\n \t\t\t >Cor: Branco e Caramelo\n");
}